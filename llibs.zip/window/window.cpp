#include <windows.h>
#include <string>
#include <sstream>
#include <wingdi.h>
#include <algorithm>
#include <array>
#include <vector>
#include <iostream>

class IRenderItem{
public:
	std::string Type = "nan";
	int x = 0;
	int y = 0;
	int w = 0;
	int h = 0;

public:
	void render(HWND hwnd, HDC hdc) {}
};

class TextItem : IRenderItem {
	std::string text;
	int fontSize = 12;

public:
	static TextItem CreateTextItem(int x, int y, std::string txt, int fs = 12) {
		TextItem val = {};

		val.x = x;
		val.y = y;
		val.text = txt;
		val.fontSize = fs;
		val.Type = "txt";

		return val;
	}
	void IRenderItem::render(HWND hwnd, HDC hdc) {
		RECT r1 = {};
		r1.left = x;
		r1.top = y;
		r1.bottom = r1.top + (fontSize * 50);
		r1.right = r1.left + (fontSize * 50);
		DrawTextA(hdc, text.c_str(), text.length(), &r1, DT_LEFT);
	}
};

template<class C, typename T>
bool contains(C&& c, T e) { return std::find(std::begin(c), std::end(c), e) != std::end(c); };

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

const char* WndClassName = "Lemon Window";

HWND wndhwnd;

std::vector<char> keys_down; 
std::vector<IRenderItem> renderItems;

void LemonWindow_CreateWindow(std::string title) {
	WNDCLASS wc = { };

	wc.lpfnWndProc = WindowProc;
	wc.hInstance = GetModuleHandle(0);
	wc.lpszClassName = WndClassName;

	RegisterClass(&wc);

	wndhwnd = CreateWindowEx(
		0,
		WndClassName,
		title.c_str(),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL,
		NULL,
		GetModuleHandle(0),
		NULL
	);

	if (wndhwnd == NULL) {
		MessageBoxA(NULL, "Error: Could not create Window, CreateWindow returned null.", title.c_str(), MB_OK | MB_ICONERROR);
		return;
	}
	
	ShowWindow(wndhwnd, 1);

	MSG msg = { };
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

int main() { return 1; }


LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;

    case WM_PAINT: 
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);

		for (size_t i = 0; i < renderItems.size(); i++)
		{
			IRenderItem irt = renderItems.at(i);
			irt.render(hwnd, hdc);
		}

		EndPaint(hwnd, &ps);
	}
        return 0;
	case WM_KEYDOWN:
		if (contains(keys_down, (char)MapVirtualKeyA(wParam, MAPVK_VK_TO_CHAR)) == FALSE) {
			keys_down.push_back((char)MapVirtualKeyA(wParam, MAPVK_VK_TO_CHAR));
		}
		break;
	case WM_KEYUP:
		keys_down.erase(std::remove(keys_down.begin(), keys_down.end(), (char)MapVirtualKeyA(wParam, MAPVK_VK_TO_CHAR)), keys_down.end());
		break;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}